Start with docs/development/reviews/2026-10-22-session-summary.md
Then docs/development/experiments/2026-10-22-experiments-summary.md
Operational details: docs/development/playbooks/three-node-handoff.md
Verify: shasum -a 256 -c SHA256SUMS
Keys and local connection settings excluded. Shared copies are not resume inputs.
