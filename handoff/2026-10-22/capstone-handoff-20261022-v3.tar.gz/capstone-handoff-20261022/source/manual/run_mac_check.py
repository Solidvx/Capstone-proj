"""Local PC orchestration for existing ECU and visible IVI; no keys leave nodes."""
import json,shlex,subprocess,time,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from security.experiments.score_mac_probe import score
cfg=json.loads((root/'tmp/pc-campaign-settings.json').read_text())
run='mac-repeat-'+time.strftime('%Y%m%d-%H%M%S')
out=root/'tmp'/run;out.mkdir()
ivi_path='ivi-evidence/block-check-20261022-060541/ivi.jsonl'
def call(role,code,timeout=20):
    cmd=cfg[role][:-1]+['python3 -c '+shlex.quote(code)]
    return subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=timeout).stdout
# Assert the existing IVI log is actively receiving current product frames.
check="""import pathlib,time,json
p=pathlib.Path.home()/PATH
if not p.exists() or time.time()-p.stat().st_mtime>5:raise SystemExit('IVI log is missing/stale: restart logged dashboard or ECU')
with p.open('rb') as f:
 f.seek(max(0,p.stat().st_size-65536)); chunk=f.read().splitlines()
rows=[]
for line in chunk:
 try:rows.append(json.loads(line))
 except ValueError:pass
frames=[r for r in rows if r.get('result')=='FRAME' and r.get('can_id')==258 and r.get('process_result')==2 and r.get('secoc_on')]
if not any(0<=time.monotonic()-int(r['timestamp_ns'])/1e9<3 for r in frames):raise SystemExit('No fresh authenticated IVI normal publication')
print('IVI_NORMAL_READY')
""".replace('PATH',repr(ivi_path))
try:
    print(call('receiver_on',check),flush=True)
    source=(root/'security/experiments/mac_rejection_probe.py').read_text()
    remote_out='tmp/'+run
    code="import os,sys;os.chdir(os.path.expanduser('~/Capstone-three-node'));sys.path.insert(0,os.getcwd());sys.argv=['mac_probe','--out',"+repr(remote_out)+",'--i-am-on-a-test-bus'];exec(compile("+repr(source)+",'mac_probe','exec'))"
    target=cfg['attacker'][:-1]+['. /dev/null; '+shlex.quote('<PI3_HOME>/Capstone-three-node/.venv-handoff/bin/python')+' -u -c '+shlex.quote(code)]
    print('30회 변조 인증 주입 시작',flush=True)
    with (out/'probe.jsonl').open('x') as log, (out/'probe.stderr').open('x') as err:
        subprocess.run(target,stdout=log,stderr=err,check=True,timeout=130)
    probe=[json.loads(x) for x in (out/'probe.jsonl').read_text().splitlines()]
    auths=[r['auth'] for r in probe if r.get('result')=='PREPARED']
    time.sleep(1)
    fetch="import json,pathlib; wanted=set("+repr(auths)+"); p=pathlib.Path.home()/"+repr(ivi_path)+"\nwith p.open() as f:\n for line in f:\n  try:r=json.loads(line)\n  except ValueError:continue\n  if r.get('result')=='FRAME' and r.get('can_id')==258 and r.get('data') in wanted:print(json.dumps(r))"
    data=call('receiver_on',fetch)
    (out/'ivi-matches.jsonl').write_text(data)
    result=score(probe,[json.loads(x) for x in data.splitlines()])
    (out/'summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='trials'},ensure_ascii=False,indent=2))
except Exception as e:
    (out/'failure.txt').write_text(str(e))
    print('STOPPED:',e)
    raise
finally:
    print('PC 결과 폴더:',out,flush=True)
