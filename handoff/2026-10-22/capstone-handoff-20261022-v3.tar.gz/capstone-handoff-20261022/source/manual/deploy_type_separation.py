"""Deploy only version-checked ECU IDS and Pi3 worker files; preserve backups."""
import base64, hashlib, json, pathlib, subprocess, datetime
root=pathlib.Path(__file__).resolve().parents[1]
settings=json.loads((root/'tmp/pc-campaign-settings.json').read_text())
remote='''import base64,hashlib,json,pathlib,sys
job=json.load(sys.stdin)
root=pathlib.Path.home()/'Capstone-three-node'
for f in job['files']:
 p=root/f['path']
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h not in (f['old'],f['new']):raise SystemExit('REFUSED modified file: '+f['path'])
for f in job['files']:
 p=root/f['path']
 if hashlib.sha256(p.read_bytes()).hexdigest()==f['new']:continue
 backup=root/'tmp'/job['backup']/f['path']
 backup.parent.mkdir(parents=True,exist_ok=True)
 with backup.open('xb') as stream:stream.write(p.read_bytes())
 temp=p.with_name(p.name+'.type-update')
 with temp.open('xb') as stream:stream.write(base64.b64decode(f['data']))
 temp.replace(p)
 print('UPDATED '+f['path'])
'''
for role,files in [('ecu',['security/ids/runtime_detector.py','security/ids/runtime.py']),('attacker',['security/experiments/can_attack_worker.py'])]:
 payload=[]
 for name in files:
  new=(root/name).read_bytes()
  old=subprocess.check_output(['git','show','HEAD:'+name],cwd=root)
  payload.append(dict(path=name,old=hashlib.sha256(old).hexdigest(),new=hashlib.sha256(new).hexdigest(),data=base64.b64encode(new).decode()))
 import shlex
 command=settings[role][:-1]+['python3 -c '+shlex.quote(remote)]
 subprocess.run(command,input=json.dumps(dict(files=payload,backup='type-separation-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))),text=True,check=True)
print('DEPLOY_COMPLETE: ECU IDS + Pi3 worker; IVI unchanged')
