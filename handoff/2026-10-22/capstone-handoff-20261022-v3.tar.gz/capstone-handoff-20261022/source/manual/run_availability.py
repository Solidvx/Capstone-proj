import json,subprocess,shlex,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cfg=json.loads((root/'tmp/pc-campaign-settings.json').read_text())
out=root/'tmp'/time.strftime('availability-%Y%m%d-%H%M%S');out.mkdir()
def remote(role,code):
 return subprocess.check_output(cfg[role][:-1]+['python3 -c '+shlex.quote(code)],text=True,timeout=15)
def stamp():return float(remote('receiver_on','import time;print(time.monotonic())'))
logpath='ivi-evidence/block-check-20261022-060541/ivi.jsonl'
remote('receiver_on',"import pathlib,time;p=pathlib.Path.home()/"+repr(logpath)+";assert p.exists() and time.time()-p.stat().st_mtime<5,'IVI log stale'")
bounds={}
bounds['baseline']=stamp();print('정상 구간 20초',flush=True);time.sleep(20)
# Both interval boundaries are sampled on IVI. SSH setup/transit is explicitly part of exposure window.
bounds['exposure']=stamp()
cmd=[x.format(run_id='AVAILABILITY',lifetime_s=45) for x in cfg['attacker']]
p=None
try:
 with (out/'attacker.jsonl').open('x') as f,(out/'attacker.stderr').open('x') as err:
  p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
  done=False
  for line in p.stdout:
   f.write(line);f.flush();r=json.loads(line)
   if r.get('result')=='READY':
    print('flooding 목표1000fps, 10초',flush=True)
    p.stdin.write(json.dumps(dict(trial=1,attack='flooding',rate=1000,duration=10,seed=103001,interface='can0',secoc=True,profile='isolated-v1'))+'\n');p.stdin.flush()
   if r.get('result')=='ATTACK_DONE':
    print(line.strip(),flush=True);done=True;p.stdin.close()
  if p.wait()!=0 or not done:raise RuntimeError('attack incomplete')
 bounds['recovery']=stamp();print('회복 구간 20초',flush=True);time.sleep(20);bounds['end']=stamp()
 code="import pathlib,json;p=pathlib.Path.home()/"+repr(logpath)+"\nwith p.open() as f:\n for line in f:\n  try:r=json.loads(line)\n  except ValueError:continue\n  if "+repr(bounds['baseline'])+"<=int(r.get('timestamp_ns',0))/1e9<="+repr(bounds['end'])+":print(json.dumps(r))"
 data=remote('receiver_on',code);(out/'ivi.jsonl').write_text(data)
 rows=[json.loads(x) for x in data.splitlines()]
 result={'bounds_ivi_monotonic':bounds,'note':'Exposure includes SSH startup/cleanup. IVI publication intervals, not cross-host latency. No automatic pass criterion.','phases':{}}
 for name,start,end in [('baseline',bounds['baseline'],bounds['exposure']),('exposure',bounds['exposure'],bounds['recovery']),('recovery',bounds['recovery'],bounds['end'])]:
  ts=sorted(int(r['timestamp_ns'])/1e9 for r in rows if r.get('result')=='FRAME' and r.get('can_id')==258 and r.get('process_result')==2 and start<=int(r['timestamp_ns'])/1e9<end)
  gaps=[(b-a)*1000 for a,b in zip(ts,ts[1:])]
  result['phases'][name]={'seconds':end-start,'published_bms':len(ts),'max_gap_ms':max(gaps) if gaps else None,'mean_gap_ms':sum(gaps)/len(gaps) if gaps else None,'first_delay_ms':(ts[0]-start)*1000 if ts else None,'last_silence_ms':(end-ts[-1])*1000 if ts else None}
 (out/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
finally:
 if p and p.poll() is None:p.terminate();p.wait()
 (out/'boundaries.json').write_text(json.dumps(bounds,indent=2))
 print('결과 폴더:',out,flush=True)
